-- AlterTable
ALTER TABLE "Task" ADD COLUMN "durationDays" INTEGER;
ALTER TABLE "Task" ADD COLUMN "priority" TEXT;
