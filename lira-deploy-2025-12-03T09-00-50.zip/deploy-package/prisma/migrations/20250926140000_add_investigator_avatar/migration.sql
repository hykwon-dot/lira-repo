ALTER TABLE `InvestigatorProfile`
  ADD COLUMN `avatarUrl` VARCHAR(255) NULL;
