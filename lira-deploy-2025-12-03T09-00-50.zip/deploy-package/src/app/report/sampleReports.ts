const sampleReports: never[] = [];

export default sampleReports;
