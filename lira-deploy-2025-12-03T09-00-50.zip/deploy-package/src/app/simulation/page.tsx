import ChatSimulation from "./ChatSimulation";

export default function SimulationPage() {
  return <ChatSimulation />;
}
