import { redirect } from "next/navigation";

export default function SimulationTestRedirect() {
	redirect("/simulation");
}

