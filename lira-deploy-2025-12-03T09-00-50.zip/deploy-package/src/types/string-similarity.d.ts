declare module 'string-similarity';
