-- AlterTable
ALTER TABLE "Phase" ADD COLUMN "description" TEXT;
