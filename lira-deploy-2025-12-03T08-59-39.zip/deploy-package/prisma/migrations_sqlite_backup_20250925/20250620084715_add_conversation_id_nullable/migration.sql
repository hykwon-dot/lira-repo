-- AlterTable
ALTER TABLE "UserSummary" ADD COLUMN "conversationId" TEXT;
