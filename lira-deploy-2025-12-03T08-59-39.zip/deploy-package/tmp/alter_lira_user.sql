ALTER USER 'lira_user'@'%' IDENTIFIED WITH mysql_native_password BY 'StrongPW123!';
