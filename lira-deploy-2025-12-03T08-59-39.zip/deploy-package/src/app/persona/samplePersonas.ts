const samplePersonas = [
  {
    id: 1,
    name: '김민수 탐정',
    segment: '불륜 조사',
    score: 92,
    description: '15년 경력의 불륜 조사 전문가. 증거 수집과 법정 증언 경험이 풍부합니다.'
  },
  {
    id: 2,
    name: '박영희 탐정',
    segment: '기업 정보 조사',
    score: 88,
    description: '대기업 출신으로 기업 내부 정보 조사 및 경쟁사 분석에 특화되어 있습니다.'
  },
  {
    id: 3,
    name: '이준호 탐정',
    segment: '실종자 수색',
    score: 95,
    description: '전직 경찰관 출신으로 실종자 수색과 인적 추적에 뛰어난 실력을 보유하고 있습니다.'
  },
  {
    id: 4,
    name: '정수연 탐정',
    segment: '신용 조사',
    score: 85,
    description: '금융기관 경력을 바탕으로 신용 조사와 재산 추적에 전문성을 가지고 있습니다.'
  },
];

export default samplePersonas;
