<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

이 프로젝트는 AI 시뮬레이션 SaaS 플랫폼입니다. 주요 기능: 회원가입/로그인, 챗GPT 연동 대화형 시뮬레이션, 관리자 대시보드, 시나리오 라이브러리, 데이터 저장 및 분석. 디자인은 https://datarize.ai/ko 유사하게 모던하고 직관적으로 구현합니다.
